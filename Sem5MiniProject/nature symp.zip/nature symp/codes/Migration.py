import pandas as pd
from tkinter import *
from tkinter import messagebox
from tkinter import ttk
from PIL import ImageTk
from matplotlib.figure import Figure
from matplotlib.backends.backend_tkagg import FigureCanvasTkAgg
def back():
    Avian_Page.destroy()
    import Home
# Function to create and display graphs
def create_and_display_graphs():
    # Read the dataset
    df = pd.read_csv("bird_migration_data.csv")

    bird_name = pri_entry.get()

    # Filter the dataset for the specific bird name
    bird_data = df[df["Bird_Name"] == bird_name]

    if bird_data.empty:
        messagebox.showinfo("Result", f"No data found for bird: {bird_name}")
    else:
        # Group data by years and calculate the total migrated and distance travelled for each year
        yearly_data = bird_data.groupby("Years_Before")[["Total_Migrated", "Distance_Traveled"]].sum()

        # Create the first graph: Years Before vs Total Migrated
        fig1 = Figure(figsize=(5, 4), dpi=100)
        ax1 = fig1.add_subplot(111)
        ax1.plot(yearly_data.index, yearly_data["Total_Migrated"], marker='o', linestyle='-', color='b')
        ax1.set_title(f"Years Before vs Total Migrated for {bird_name}")
        ax1.set_xlabel("Years_Before")
        ax1.set_ylabel("Total_Migrated")
        ax1.grid(True)

        # Create the second graph: Years Before vs Distance Travelled
        fig2 = Figure(figsize=(5, 4), dpi=100)
        ax2 = fig2.add_subplot(111)
        ax2.plot(yearly_data.index, yearly_data["Distance_Traveled"], marker='o', linestyle='-', color='g')
        ax2.set_title(f"Years Before vs Distance Travelled for {bird_name}")
        ax2.set_xlabel("Years_Before")
        ax2.set_ylabel("Distance_Traveled")
        ax2.grid(True)

        # Embed Matplotlib figures into the Tkinter window
        canvas1 = FigureCanvasTkAgg(fig1, master=Avian_Page)
        canvas1_widget = canvas1.get_tk_widget()
        canvas1_widget.place(x=200, y=300)

        canvas2 = FigureCanvasTkAgg(fig2, master=Avian_Page)
        canvas2_widget = canvas2.get_tk_widget()
        canvas2_widget.place(x=700, y=300)

# Create the Tkinter window and run the application
Avian_Page = Tk()
Avian_Page.title("Avian Page")
Avian_Page.geometry('1366x768')
Avian_Page.iconbitmap('')

cd_bg_image = ImageTk.PhotoImage(file='images//Migration.png')
cd_bg_label = Label(Avian_Page, image=cd_bg_image)
cd_bg_label.place(x=0, y=0)

lbl_pri = Label(Avian_Page, text='Bird Name', font=('Times New Roman', 25, 'bold'), fg='black', bg='white')
lbl_pri.place(x=400, y=130)

pri_entry = Entry(Avian_Page, width=10, border=15, font=('Times New Roman', 25), bd=0, fg='black', bg='white')
pri_entry.place(x=700, y=130)

Button(Avian_Page, text='Ok', font=('Open Sans', 20, 'bold'), fg='black', bg='gray', cursor='hand2', bd=0,
       width=20, height=1, command=create_and_display_graphs).place(x=500, y=190)

Button(Avian_Page, text='Back', font=('Open Sans', 20, 'bold'), fg='black', bg='white', cursor='hand2',
        bd=0, width=10, height=1, command= back).place(x=1170,y=60)
# Run the Tkinter main loop
Avian_Page.mainloop()
