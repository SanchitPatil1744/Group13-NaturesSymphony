from tkinter import *
from tkinter import messagebox
from PIL import Image, ImageTk
import pandas as pd
from tkinter import ttk

# Function to classify the bird based on input values

def back():
    avian_window.destroy()
    import Home
def classify_bird():
    primary_color = pri_entry.get()
    secondary_color = sec_entry.get()
    num_digits = digit_entry.get()
    zone = zone_entry.get()
    flight = flight_entry.get()  # Get the flight input

    if not primary_color or not secondary_color or not num_digits or not zone or not flight:
        messagebox.showerror("Error", "Please fill in all fields.")
        return

    # Read data from the CSV file
    try:
        bird_data = pd.read_csv("BIRDSs.csv")
        query = f"Primary == '{primary_color}' and Secondary == '{secondary_color}' and digits == {num_digits} and Zone == '{zone}' and Flight == '{flight}'"  # Include Flight in the query
        filtered_data = bird_data.query(query)

        if not filtered_data.empty:
            bird_name = filtered_data.iloc[0]['Bird']
            scientific_name = filtered_data.iloc[0]['Scientific']
            image_path = filtered_data.iloc[0]['ImageBird'] + '.jpg'  # Corrected image path

            try:
                img = Image.open(image_path)
                img = ImageTk.PhotoImage(img)
                lbl_image.config(image=img)
                lbl_image.image = img
            except Exception as e:
                lbl_image.config(image="")
                print("Error loading image:", str(e))

            lbl_text.config(text=f'Bird name: {bird_name}')
            lbl_text2.config(text=f'Scientific name: {scientific_name}')
            lbl_flight.config(text=f'Flight: {flight}')  # Display the Flight attribute
        else:
            messagebox.showinfo("Result", "No matching bird found.")
    except Exception as e:
        messagebox.showerror("Error", f"An error occurred: {str(e)}")

# Create the Tkinter window
avian_window = Tk()
avian_window.title("Avian Page")
avian_window.geometry('1366x768')
avian_window.iconbitmap('')

# Set the background image
bg_image = Image.open('images//Avian.png')
bg_photo = ImageTk.PhotoImage(bg_image)
bg_label = Label(avian_window, image=bg_photo)
bg_label.place(x=0, y=0, relwidth=1, relheight=1)

# Create and place input fields and labels
font_style = ('Times New Roman', 25, 'bold')
fg_color = 'black'
bg_color = 'white'

lbl_pri = Label(avian_window, text='Primary color', font=font_style, fg=fg_color, bg=bg_color)
pri_entry = Entry(avian_window, width=10, font=font_style, bd=10, fg='black', bg='white')
lbl_sec = Label(avian_window, text='Secondary color', font=font_style, fg=fg_color, bg=bg_color)
sec_entry = Entry(avian_window, width=10, font=font_style, bd=10, fg='black', bg='white')
lbl_digit = Label(avian_window, text='No. of fingers', font=font_style, fg=fg_color, bg=bg_color)
digit_entry = Entry(avian_window, width=10, font=font_style, bd=10, fg='black', bg='white')
lbl_zone = Label(avian_window, text='Zone', font=font_style, fg=fg_color, bg=bg_color)

# Define zone options
zone_options = ["Desert", "Rainforest", "Polar", "Urban", "Suburban", "Rural", "Wetland", "Garden", "Lake", "Forest", "Savannah", "Polar"]
zone_entry = ttk.Combobox(avian_window, state="readonly", values=zone_options, width=10, font=font_style)
lbl_flight = Label(avian_window, text='Flight', font=font_style, fg=fg_color, bg=bg_color)
flight_entry = ttk.Combobox(avian_window, state="readonly", values=["Yes", "No"], width=10, font=font_style)  # Flight options


# Create and place the "Back" button
btn_back = Button(avian_window, text='Back', font=font_style, fg='black', bg='white', cursor='hand2', bd=0, command=back)

# Create and place the "Estimate" button
btn_estimate = Button(avian_window, text='Estimate', font=font_style, fg='black', bg='gray', cursor='hand2', bd=0, command=classify_bird)

# Place labels and input fields on the window
lbl_pri.place(x=100, y=150)
pri_entry.place(x=400, y=150)
lbl_sec.place(x=100, y=250)
sec_entry.place(x=400, y=250)
lbl_digit.place(x=100, y=350)
digit_entry.place(x=400, y=350)
lbl_zone.place(x=100, y=550)
zone_entry.place(x=400, y=550)
lbl_flight.place(x=100, y=450)  # Display the Flight label
flight_entry.place(x=400, y=450)  # Display the Flight input field

btn_back.place(x=1150, y=90)
btn_estimate.place(x=300, y=650)

# Create and place the labels for bird name, scientific name, and image
lbl_image = Label(avian_window)
lbl_image.place(x=750, y=350)
lbl_text = Label(avian_window, text='', font=font_style, fg=fg_color, bg=bg_color)
lbl_text.place(x=750, y=150)
lbl_text2 = Label(avian_window, text='', font=font_style, fg=fg_color, bg=bg_color)
lbl_text2.place(x=750, y=250)
lbl_text3 = Label(avian_window, text='', font=font_style, fg=fg_color, bg=bg_color)
lbl_text3.place(x=750, y=450)

# Start the Tkinter main loop
avian_window.mainloop()
