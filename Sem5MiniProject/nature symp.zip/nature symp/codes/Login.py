import tkinter as tk
from tkinter import ttk
from tkinter import messagebox
import mysql.connector

def login():
    # # Connect to the database
    # db = mysql.connector.connect(
    #     host="localhost",
    #     user="NatureSym",
    #     password="Sanchit@2004",
    #     database="NS"
    # )
    # cursor = db.cursor()

    # username = entry_username.get()
    # password = entry_password.get()

    # query = "SELECT * FROM users WHERE username = %s AND password = %s"
    # cursor.execute(query, (username, password))
    # result = cursor.fetchone()

    # if result:
    #     messagebox.showinfo("Login Successful", "Welcome to the Home Page!")
    #     import Home
    # else:
    #     messagebox.showerror("Login Failed", "Invalid username or password")
    window.destroy()
    import Home

def register():
    window.destroy()
    import Register

# Create the main window
window = tk.Tk()
window.title("Login")
window.geometry("1366x768")
window.configure(bg="white")

# Load the background image
bg_image = tk.PhotoImage(file="images/Login.png")
bg_label = tk.Label(window, image=bg_image)
bg_label.place(relwidth=1, relheight=1)

# Create a custom ttk style with the desired font
custom_style = ttk.Style()
custom_style.configure("Custom.TButton", font=('Times New Roman', 25, 'bold'))

# Create and configure labels, entry widgets, and buttons
label_username = tk.Label(window, text="Username", font=('Times New Roman', 25, 'bold'), fg='black', bg='white')
label_password = tk.Label(window, text="Password", font=('Times New Roman', 25, 'bold'), fg='black', bg='white')
entry_username = ttk.Entry(window, font=('Times New Roman', 25))
entry_password = ttk.Entry(window, show="*", font=('Times New Roman', 25))
login_button = ttk.Button(window, text="Login", style="Custom.TButton", command=login)
register_button = ttk.Button(window, text="Don't have an account? Register here", style="Custom.TButton", command=register)

# Place labels, entry widgets, and buttons on the window
label_username.place(x=200, y=300)
label_password.place(x=200, y=400)
entry_username.place(x=500, y=300)
entry_password.place(x=500, y=400)
login_button.place(x=500, y=500)
register_button.place(x=350, y=550)

window.mainloop()
