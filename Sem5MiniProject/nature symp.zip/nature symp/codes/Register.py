import tkinter as tk
from tkinter import ttk
from tkinter import messagebox
import mysql.connector
from tkinter import *

def register():
    name = entry_name.get()
    username = entry_username.get()
    password = entry_password.get()
    phone = entry_phone.get()

    if not name or not username or not password or not phone:
        messagebox.showerror("Error", "Please fill in all fields.")
        return

    try:
        # Connect to the database
        db = mysql.connector.connect(
            host="localhost",
            user="root",
            password="Sanchit@2004",
            database="NS"
        )
        cursor = db.cursor()

        # Check if the username already exists
        query = "SELECT * FROM users WHERE username = %s"
        cursor.execute(query, (username,))
        existing_user = cursor.fetchone()

        if existing_user:
            messagebox.showerror("Registration Failed", "Username already exists. Please choose a different username.")
        else:
            # Insert the new user into the database
            insert_query = "INSERT INTO users (name, username, password, phone) VALUES (%s, %s, %s, %s)"
            cursor.execute(insert_query, (name, username, password, phone))
            db.commit()

            messagebox.showinfo("Registration Successful", "You have successfully registered!")

            # You can optionally navigate to the Login page here
    except mysql.connector.Error as err:
        messagebox.showerror("Database Error", f"Error: {err}")

# Create the main window
window = tk.Tk()
window.title("Register")
window.geometry("1366x768")
window.configure(bg="white")

# Load the background image
bg_image = tk.PhotoImage(file="images/Register.png")
bg_label = tk.Label(window, image=bg_image)
bg_label.place(relwidth=1, relheight=1)

# Create and configure labels, entry widgets, and buttons
label_name = tk.Label(window, text="Name", font=('Times New Roman', 25, 'bold'), fg='black', bg='white')
label_username = tk.Label(window, text="Username", font=('Times New Roman', 25, 'bold'), fg='black', bg='white')
label_password = tk.Label(window, text="Password", font=('Times New Roman', 25, 'bold'), fg='black', bg='white')
label_phone = tk.Label(window, text="Phone", font=('Times New Roman', 25, 'bold'), fg='black', bg='white')

entry_name = ttk.Entry(window, font=('Times New Roman', 25, 'bold'))
entry_username = ttk.Entry(window, font=('Times New Roman', 25, 'bold'))
entry_password = ttk.Entry(window, show="*", font=('Times New Roman', 25, 'bold'))
entry_phone = ttk.Entry(window, font=('Times New Roman', 25, 'bold'))

# register_button = ttk.Button(window, text="Register", command=register, style="TButton", width=20)
Button(window, text='Register', font=('Open Sans', 20, 'bold'), fg='black', bg='gray', cursor='hand2', bd=0,
       width=20, height=1, command=register).place(x=400, y=600)
# Place labels, entry widgets, and buttons on the window
label_name.place(x=200, y=200)
label_username.place(x=200, y=300)
label_password.place(x=200, y=400)
label_phone.place(x=200, y=500)

entry_name.place(x=400, y=200)
entry_username.place(x=400, y=300)
entry_password.place(x=400, y=400)
entry_phone.place(x=400, y=500)

# register_button.place(x=400, y=650)

window.mainloop()
